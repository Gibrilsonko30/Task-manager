import React from "react";
import TaskTable from "./components/TaskTable.jsx"; // Ensure the file extension is included

function App() {
  return (
    <div>
      <TaskTable />
    </div>
  );
}

export default App;
